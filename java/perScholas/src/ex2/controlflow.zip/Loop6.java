package ex2;

public class Loop6 {
	
	public static void main(String[] args) {
		for(int week = 1; week <= 2; week++) {
			System.out.println();
			System.out.println("week " + week);
			
			for(int day = 1; day <=5; day++) {
				System.out.println("day " + day);
				}
			}
		}
	}



package ex2;

public class Loop5 {

	public static void main(String[] args) {
		for(int i = 0; i <= 100; i+=5) {
			System.out.println(i);
			if(i>=50) {
				break;
			}
			
		}
	}
}

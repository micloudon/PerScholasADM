package ex2;

public class Loop3 {
	public static void main(String[] args) {
		int i = 0;
		
		do {
			i++;
			System.out.println(i);
		}
		
		while(i<10);
	}
}

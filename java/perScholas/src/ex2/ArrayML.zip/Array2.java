package ex2;

public class Array2 {
	
	public static void main(String[] args) {
		int arr[] =  {13, 5, 7, 68, 2};
		
		System.out.println(arr[2]);
	}
}

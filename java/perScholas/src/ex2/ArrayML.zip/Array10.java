package ex2;

import java.util.Arrays;

public class Array10 {
	public static void main(String[] args) {
		String arr[] = {4, "A", "B", "C", 1.444};
		
		
		System.out.println(Arrays.toString(arr));
	}
}

package ex2;

public class Array4 {
	
	public static void main(String[] args) {
		int arr[] = {1,2,3,4,5};
		
		System.out.println(arr[0]);
		System.out.println(arr[arr.length -1]);
		System.out.println(arr[arr.length]);
	}

}
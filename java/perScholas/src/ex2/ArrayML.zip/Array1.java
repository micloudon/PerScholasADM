package ex2;
import java.util.Arrays;

public class Array1 {
	
	public static void main(String[] args) {
		int arr[] = {1,2,3};
		
		System.out.println(Arrays.toString(arr));
	}

}

package perScholas;

public class AdditionID {
	public static void main(String[] args) {
		double num1 = 10.1;
		int num2 = 15;
		
		double sum = num1 + num2;
		
		System.out.println(sum);
	}
}

package perScholas;

public class Coins {
	int penny = 1;
	int nickel = 5;
	int dime = 10;
	int quarter = 25;
	int dollar = 100;
}

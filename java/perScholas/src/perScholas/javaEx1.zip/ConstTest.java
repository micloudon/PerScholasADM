package perScholas;

public class ConstTest {
	
	public static void main(String[] args) {
	
		final int num = 100;
		
		int num1 = 20;
		
		int sum = num + num1;
		
		System.out.println(sum);
	
	}

}

package perScholas;

public class DivisionD {
	public static void main(String[] args) {
		double num1 = 22.5;
		double num2 = 10;
		
		double quotient = num1 / num2;
//		int quotient1 = num1 / num2; Type mismatch: cannot convert from double to int
		
		System.out.println(quotient);
	}

}

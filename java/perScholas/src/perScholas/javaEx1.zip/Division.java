package perScholas;

public class Division {
	public static void main(String[] args) {
		int num1 = 20;
		int num2 = 10;
		
		int quotient = num1 / num2;
		
		System.out.println(quotient);
	}

}
